/*
 * config.h
 *
 */

#ifndef MATH_CONFIG_H_
#define MATH_CONFIG_H_

//#define MAX_MOD_SZ 6

#endif /* MATH_CONFIG_H_ */
