/*
 * config.h
 *
 */

#ifndef BMR_CONFIG_H_
#define BMR_CONFIG_H_

// change number of parties here or omit to allow any number
//#define N_PARTIES 2
#define MAX_N_PARTIES 3

#define MAX_INLINE

//#define SIGNAL_CHECK
//#define DEBUG_MASK

#endif /* BMR_CONFIG_H_ */
