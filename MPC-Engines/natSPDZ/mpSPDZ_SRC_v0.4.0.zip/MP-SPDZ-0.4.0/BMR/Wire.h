
#ifndef __WIRE_H__
#define __WIRE_H__

#include <vector>

#include "Key.h"
#include "common.h"

class Gate;

#define NO_SIGNAL (2) //since this is a boolean circuit, valid values are either 0 or 1.

#endif
