
#ifndef __BOOLEAN_CIRCUIT__
#define __BOOLEAN_CIRCUIT__

#include "Party.h"

#define MSG_KEYS_HEADER_SZ (16)

#endif
