/*
 * yao-player.cpp
 *
 */

#include "Yao/YaoPlayer.h"

int main(int argc, const char** argv)
{
	YaoPlayer(argc, argv);
}
