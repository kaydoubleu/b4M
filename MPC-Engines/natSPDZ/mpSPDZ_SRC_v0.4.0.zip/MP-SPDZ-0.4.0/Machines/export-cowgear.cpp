/*
 * export-vm.cpp
 *
 */

#include "maximal.hpp"

template class Machine<CowGearShare<gfp_<0, 2>>>;
