/*
 * export-vm.cpp
 *
 */

#include "maximal.hpp"

template class Machine<HemiShare<gfp_<0, 2>>>;
