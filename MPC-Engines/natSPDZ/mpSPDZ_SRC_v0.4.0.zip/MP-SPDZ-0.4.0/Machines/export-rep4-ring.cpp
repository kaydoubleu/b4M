/*
 * export-vm.cpp
 *
 */

#include "maximal.hpp"

template class Machine<Rep4Share2<64>>;
