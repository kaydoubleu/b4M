/*
 * Rep4.hpp
 *
 */

#ifndef MACHINES_REP4_HPP_
#define MACHINES_REP4_HPP_

#include "GC/Rep4Secret.h"
#include "GC/Rep4Prep.h"
#include "Protocols/Rep4Share2k.h"
#include "Protocols/Rep4Prep.h"
#include "Protocols/Rep4.hpp"
#include "Protocols/Rep4MC.hpp"
#include "Protocols/Rep4Input.hpp"
#include "Protocols/Rep4Prep.hpp"

#endif /* MACHINES_REP4_HPP_ */
