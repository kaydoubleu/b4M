/*
 * export-vm.cpp
 *
 */

#include "maximal.hpp"

template class Machine<AtlasShare<gfp_<0, 2>>>;
