/*
 * export-vm.cpp
 *
 */

#include "maximal.hpp"

template class Machine<Semi2kShare<64>>;
