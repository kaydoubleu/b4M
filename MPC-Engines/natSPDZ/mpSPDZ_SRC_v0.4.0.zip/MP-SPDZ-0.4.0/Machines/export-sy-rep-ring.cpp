/*
 * export-vm.cpp
 *
 */

#include "maximal.hpp"

template class Machine<SpdzWiseRingShare<64, 40>>;
