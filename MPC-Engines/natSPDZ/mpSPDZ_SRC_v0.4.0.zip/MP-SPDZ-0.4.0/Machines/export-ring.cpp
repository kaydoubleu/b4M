/*
 * export-vm.cpp
 *
 */

#include "maximal.hpp"

template class Machine<Rep3Share2<64>>;
