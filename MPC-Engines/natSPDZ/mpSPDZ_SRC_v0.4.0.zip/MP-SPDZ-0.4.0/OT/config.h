/*
 * config.h
 *
 */

#ifndef OT_CONFIG_H_
#define OT_CONFIG_H_

#define USE_OPT_VOLE 1
#define NUM_VOLE_CHALLENGES 3

#endif /* OT_CONFIG_H_ */
