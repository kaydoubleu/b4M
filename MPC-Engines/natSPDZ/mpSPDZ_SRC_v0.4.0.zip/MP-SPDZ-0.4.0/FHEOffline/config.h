/*
 * config.h
 *
 */

#ifndef FHEOFFLINE_CONFIG_H_
#define FHEOFFLINE_CONFIG_H_

#ifndef LESS_MEM_MORE_ALLOC
#define LESS_ALLOC_MORE_MEM
#endif

#ifndef COMP_SEC
#define COMP_SEC 128
#endif

#endif /* FHEOFFLINE_CONFIG_H_ */
