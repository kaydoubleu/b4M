/*
 * mal-rep-ecdsa-party.cpp
 *
 */

#include "Protocols/Rep3Share.h"

#include "hm-ecdsa-party.hpp"

int main(int argc, const char** argv)
{
    run<Rep3Share>(argc, argv);
}
