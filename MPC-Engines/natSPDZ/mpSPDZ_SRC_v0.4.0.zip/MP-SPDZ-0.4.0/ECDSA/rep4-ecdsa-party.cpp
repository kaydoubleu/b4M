/*
 * rep4-ecsda-party.cpp
 *
 */

#include "Machines/Rep4.hpp"

#include "hm-ecdsa-party.hpp"

int main(int argc, const char** argv)
{
    run<Rep4Share>(argc, argv);
}
