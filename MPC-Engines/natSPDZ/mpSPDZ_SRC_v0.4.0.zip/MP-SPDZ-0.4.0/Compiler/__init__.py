from . import compilerLib, program, instructions, types, library, floatingpoint
from .GC import types as GC_types
import inspect
from .config import *
