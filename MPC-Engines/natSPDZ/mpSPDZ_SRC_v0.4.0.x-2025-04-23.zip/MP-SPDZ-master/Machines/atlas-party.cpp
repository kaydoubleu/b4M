/*
 * atlas-party.cpp
 *
 */

#include "Atlas.hpp"

int main(int argc, const char** argv)
{
    ShamirMachineSpec<AtlasShare>(argc, argv);
}
