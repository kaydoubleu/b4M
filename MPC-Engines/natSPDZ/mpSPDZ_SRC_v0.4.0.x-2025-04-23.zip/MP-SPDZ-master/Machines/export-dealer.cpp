/*
 * export-vm.cpp
 *
 */

#include "maximal.hpp"

template class Machine<DealerShare<SignedZ2<64>>>;
