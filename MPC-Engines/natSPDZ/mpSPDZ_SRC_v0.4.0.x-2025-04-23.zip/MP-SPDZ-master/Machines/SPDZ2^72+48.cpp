/*
 * SPDZ2^(64+48).cpp
 *
 */

#include "SPDZ2k.hpp"

template class Machine<Spdz2kShare<72, 48>, Share<gf2n>>;
