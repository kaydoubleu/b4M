/*
 * OText_main.cpp
 *
 */

#include "OTMachine.h"

int main(int argc, const char** argv)
{
    OTMachine(argc, argv).run();
}
