/*
 * config.h
 *
 */

#ifndef GC_CONFIG_H_
#define GC_CONFIG_H_

//#define CHECK_SIZE

//#define COUNT_INSTRUCTIONS

//#define CHECK_SIZE

#endif /* GC_CONFIG_H_ */
